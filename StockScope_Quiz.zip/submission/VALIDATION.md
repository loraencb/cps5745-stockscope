# Verification record

## Automated checks

- **21 tests passed** using Python 3.12 in the Quiz project's isolated environment.
- `pip check`: no broken requirements.
- The return checks include a hand-calculated 10% gain followed by a 10% loss: the compounded period return must be -1%, not 0%.
- Inclusive date filtering, a common starting date, missing quotes, shared histogram bins and axis ranges, independent correlation calculations, and daily sample standard deviation were checked.
- Provider checks confirm adjusted closes are used and unfinished sessions are excluded, including an exchange-reported early close.
- Streamlit tests exercise the company selector, date range, empty selection, insufficient data, and complete download failure.

## Actual running application

`scripts/verify_browser.py` ran against the local dashboard in a new Chrome browser context with no sign-in cookies.

- Five Plotly visualizations rendered without application or JavaScript errors.
- The default comparison included AAPL, MSFT, and NVDA, October 16, 2025 through October 16, 2026.
- It contained 252 shared closing dates and 251 shared daily returns.
- The app's downloaded adjusted-price CSV was used to independently recompute the indexed series, period returns, daily-return arrays, and Pearson correlations. All matched the plotted values.
- Removing Microsoft updated every chart and the findings.
- Changing the start month through the visible date control updated every chart and the findings.
- Clearing the company selection showed the intended message and removed the charts without crashing.

The default adjusted period returns in this verified run were Apple +39.31%, Microsoft +4.26%, and NVIDIA +18.06%. NVIDIA had the widest day-to-day variation. These findings describe this specific period, not a prediction.

The exact verification timestamp, URL, values, observations, and screenshot filenames are recorded in `local_preview/verification.json`.

## Public deployment verified

- Public dashboard: https://braulio-stockscope.streamlit.app/
- Host: Streamlit Community Cloud; Python 3.12; public GitHub repository; main branch; app.py entrypoint; no secrets.
- Browser session: fresh signed-out Chrome context.
- Verified at: 2026-10-19T13:42:43.824763+00:00.
- The app loaded without signing in. Community Cloud embeds the application in a frame for signed-out visitors; the verifier checks that actual app frame and captures the public page.
- All five rendered charts were checked against an independently recomputed adjusted-close CSV. Period returns, indexed series, daily-return arrays, and Pearson correlations matched.
- Removing Microsoft updated all five charts and the findings.
- Changing the start month using the visible date filter updated all five chart datasets and the findings.
- Clearing the company selection showed the intended message with no charts and no application exception.
- No JavaScript or application errors occurred.
- All three deployed screenshots were visually inspected. Together they show all five chart titles, axes, units, company and date filters, full name, and exact course statement.

Machine-readable report: `deployed_screenshots/verification.json`. The earlier `local_preview/` folder is retained only as development evidence; submit the deployed screenshots listed in `SUBMISSION.md`.
