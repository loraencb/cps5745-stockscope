# Question 12 submission

**Braulio Lora Encarnacion**  
**Developed for CPS*5745**

## Live dashboard

https://braulio-stockscope.streamlit.app/

The public dashboard opens without signing in. The deployed app was checked in a fresh signed-out Chrome browser on October 19, 2026. Both filters update all five visualizations and the Key Findings.

## Submit these screenshots

1. [Overview and indexed performance](deployed_screenshots/01_overview_and_performance.png)
2. [Period returns, box plot, and daily-return histograms](deployed_screenshots/02_return_spread_and_histograms.png)
3. [Correlation heatmap and Key Findings](deployed_screenshots/03_correlation_and_findings.png)

All screenshots came from the public deployed app. Each shows the selected companies and dates in the sidebar, my full name, and the course statement. Together they show all five comparison charts. Submit all three images with the live URL.

The screenshots use AAPL, MSFT, and NVDA for October 16, 2025 through October 16, 2026, the latest available year at capture. October 19's market session was still unfinished. There are 252 shared closing dates and 251 daily observations. The dashboard refreshes from Yahoo Finance and shows its latest trading date and refresh timestamp.

## Source and instructions

- `StockScope_Quiz.zip`: complete source, dependency files, README, tests, verification script, and submission screenshots.
- `app.py`, `market_data.py`, `analytics.py`, `charts.py`: application source.
- `requirements.txt`: pinned application dependencies, tested with Python 3.12.
- `.streamlit/config.toml`: theme and server settings.
- `README.md`: setup, run, deployment instructions, chart explanations, and calculations.
- `VALIDATION.md` and `deployed_screenshots/verification.json`: verification evidence.
- Public repository: https://github.com/loraencb/cps5745-stockscope

## How I would explain it in class

I compared Apple, Microsoft, and NVIDIA over the same dates. The line chart starts every company at 100, which makes their growth easier to compare even though their share prices are different. The bar chart shows the overall percentage gain or loss. The histogram and box plot show how much daily returns moved around. The heatmap shows how closely the companies' daily returns moved together.

For the year shown in my screenshots, Apple had the largest adjusted gain at 39.31%, followed by NVIDIA at 18.06% and Microsoft at 4.26%. NVIDIA had the most day-to-day variation. Microsoft and NVIDIA had the strongest correlation, but it was only 0.25. These findings change when I change the filters.

I used adjusted closing prices to account for splits and cash dividends. The returns are a total-return proxy before fees and taxes. I calculate period return as `(last adjusted close / first adjusted close - 1) * 100`, and daily returns use consecutive trading-day prices. All companies share comparison dates, and missing prices are not filled in.
